# coding: utf8

import re
import os
import ntpath
import platform
import shutil
import webbrowser
from languagestrings import LanguageStrings
from subprocess import Popen
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
from tkinter import *
from PIL import ImageTk, Image


def change_status_of_action_buttons(newstate):
    all_action_buttons=[goToSelectAutosomalFormatsButton,mitoFASTAButton,yANDmtButton,yOnlyButton,bamCheckWithSamtoolsButton,haplogroupYButton,haplogroupMtButton,exportUnmappedReadsButton]
    for single_button in all_action_buttons:
        single_button.configure(state = newstate)
    if newstate=="normal" and mainWindow.gender==wgse_lang.lstr['Female']:
        haplogroupYButton.configure(state = "disabled")
        yOnlyButton.configure(state = "disabled")        

def check_if_all_filenames_are_set_for_change_of_button_state():
    if mainWindow.inputbam_filename == "" or mainWindow.outputfiles_path == "":
        change_status_of_action_buttons("disabled")
    else:
        change_status_of_action_buttons("normal")

def create_batch_file(path_and_filename_for_batch, commands_for_batch):
    path_and_filename_for_batch = path_and_filename_for_batch + os_batch_suffix
    f=open(path_and_filename_for_batch,"w+")
    if platform.system()=="Darwin" or platform.system()=="Linux":
        f.write("#!/bin/sh\n")
    f.write(commands_for_batch)
    f.close()
    if platform.system()=="Darwin":
        run_external_program(["/bin/chmod","ugoa+x",path_and_filename_for_batch])
    elif platform.system()=="Linux":
        run_external_program(["chmod","ugoa+x",path_and_filename_for_batch])

def button_continueAfterFiletypeError():
    global errUnsupportedFiletypeWindow
    errUnsupportedFiletypeWindow.destroy()    
    try:
        mainWindow.update()
        mainWindow.deiconify()
    except:
        pass

def show_error_unsupported_filetype(unsupported_filetype_error_message):
    global errUnsupportedFiletypeWindow
    mainWindow.inputbam_filename=""
    mainWindow.gender=""
    bamSelectedFileLabel.configure(text = "")
    referenceGenomeOfBamLabel.configure(text = "")
    bamGenderLabel.configure(text = "")
    bamAverageReadDepthLabel.configure(text = "")
    bamAverageReadLengthLabel.configure(text = "")
    change_status_of_action_buttons("disabled")
    bamSelectButton.configure(text = wgse_lang.lstr['SelectBamFile'])

    try:
        mainWindow.withdraw()
    except:
        pass
    errUnsupportedFiletypeWindow = Tk()
    errUnsupportedFiletypeWindow.title(wgse_lang.lstr['Error'])
    errUnsupportedFiletypeWindow.geometry("")
    errUnsupportedFiletypeWindow.protocol("WM_DELETE_WINDOW",0)
    if(platform.system()=="Windows"):
        errUnsupportedFiletypeWindow.iconbitmap('favicon.ico')
    errUnsupportedFiletypeWindow.columnconfigure(0, weight=1)
    errUnsupportedFiletypeWindow.rowconfigure(0, weight=1)
    errMessUFLabel = Label(errUnsupportedFiletypeWindow, text=unsupported_filetype_error_message, font=("Times New Roman", 14), anchor="w", justify="left") 
    errMessUFLabel.grid(column=0, row=0, padx=5,pady=5)
    continueButton = Button(errUnsupportedFiletypeWindow, text=wgse_lang.lstr['Continue'], font=("Times New Roman", 14),command=button_continueAfterFiletypeError)
    continueButton.grid(column=0, row=1, padx=5,pady=5)
    errUnsupportedFiletypeWindow.update()
	
def determine_reference_genome_used_for_bam():
    global askRefgenWindow
    if(platform.system()=="Darwin"):
        grep = confp_to_bash(path_to_samtools_cygwin + "ggrep")
    else:
        grep = confp_to_bash(path_to_samtools_cygwin + "grep")
    commands_for_batch = "\"" + path_to_samtools_cygwin + "samtools\" view -H \""+mainWindow.inputbam_filename+"\" > " + path_to_temp + "bamheader.tmp" + "\n"        
    commands_for_batch = commands_for_batch  + "\"" + grep + "\" '@SQ\tSN:chr1\tLN:.*$' -m 1 -o " + path_to_temp + "bamheader.tmp" + "> \"" + path_to_temp + "refgen2.tmp\"\n"
    commands_for_batch = commands_for_batch  + "\"" + grep + "\" '@SQ\tSN:1\tLN:.*$' -m 1 -o "+ path_to_temp + "bamheader.tmp" + "> \"" + path_to_temp + "refgen3.tmp\"\n"
    commands_for_batch = commands_for_batch  + "\"" + grep + "\" '@SQ\tSN:MT\tLN:.*$' -m 1 -o "+ path_to_temp + "bamheader.tmp" + "> \"" + path_to_temp + "refgen4.tmp\"\n"
    create_batch_file(path_to_temp + "temp_determine_refgenom",commands_for_batch)
    run_external_program([path_to_temp + "temp_determine_refgenom" + os_batch_suffix])
    os.remove(path_to_temp + "temp_determine_refgenom" + os_batch_suffix)
    f=open(path_to_temp + "refgen2.tmp", "r")
    contents2 =f.read()
    f.close()
    f=open(path_to_temp + "refgen3.tmp", "r")
    contents3 =f.read()
    f.close()
    f=open(path_to_temp + "refgen4.tmp", "r")
    contents4 =f.read()
    f.close()    
    f=open(path_to_temp + "bamheader.tmp", "r")
    contents5 =f.read()
    f.close()
    mainWindow.withdraw()
    mainWindow.BamAlignedToMito = "rCRS"
    mainWindow.BamAlignedToRefgenome = "0"
    clean_temp_dir()
    if "@SQ\tSN:hs37d5" in contents5:
        mainWindow.BamAlignedToRefgenome = "hs37d5"
    elif "249250621" in contents2:
        mainWindow.BamAlignedToRefgenome = "hg19"
        mainWindow.BamAlignedToMito = "Yoruba"
    elif "249250621" in contents3:
        mainWindow.BamAlignedToRefgenome = "GRCh37"            
    elif "248956422" in contents2:
        mainWindow.BamAlignedToRefgenome = "hg38"        
    elif "248956422" in contents3:
        mainWindow.BamAlignedToRefgenome = "GRCh38"        
    if mainWindow.BamAlignedToRefgenome == "0":
        textToDisplay = wgse_lang.lstr['CouldntDetermineReferenceGenome']
        textToDisplay = textToDisplay + wgse_lang.lstr['PleaseSelectReferenceManually']
    else:
        set_refgenom_after_button_click(mainWindow.BamAlignedToRefgenome)
        return
    
    if mainWindow.BamAlignedToRefgenome == "0":
        try:
            mainWindow.withdraw()
        except:
            pass
        textToDisplay = textToDisplay + wgse_lang.lstr['CautionSelectTheCorrectRefGenome']
        askRefgenWindow = Tk()
        askRefgenWindow.protocol("WM_DELETE_WINDOW",0)
        askRefgenWindow.title(wgse_lang.lstr['ToWhichRefGenomeHasBAMBeenAlignedTo'])
        askRefgenWindow.geometry("")
        if(platform.system()=="Windows"):
            askRefgenWindow.iconbitmap('favicon.ico')
        askRefgenWindow.columnconfigure(0, weight=1)
        askRefgenWindow.rowconfigure(0, weight=1)    
        questionWhichRefgenLabel = Label(askRefgenWindow, text=textToDisplay, font=("Times New Roman", 14), anchor="w", justify="left") 
        questionWhichRefgenLabel.grid(column=0, row=0, padx=5,pady=5)
        hg19Button = Button(askRefgenWindow, text=wgse_lang.lstr['RefGenomIsHG19'], font=("Times New Roman", 14),command= lambda: set_refgenom_after_button_click("hg19"))
        hg19Button.grid(column=0, row=1, padx=5,pady=5)
        grch37Button = Button(askRefgenWindow, text=wgse_lang.lstr['RefGenomIsGRCh37'], font=("Times New Roman", 14),command= lambda: set_refgenom_after_button_click("GRCh37"))
        grch37Button.grid(column=0, row=2, padx=5,pady=5)
        hg38Button = Button(askRefgenWindow, text=wgse_lang.lstr['RefGenomIsHG38'], font=("Times New Roman", 14),command= lambda: set_refgenom_after_button_click("hg38"))
        hg38Button.grid(column=0, row=3, padx=5,pady=5)
        grch38Button = Button(askRefgenWindow, text=wgse_lang.lstr['RefGenomIsGRCh38'], font=("Times New Roman", 14),command= lambda: set_refgenom_after_button_click("GRCh38"))
        grch38Button.grid(column=0, row=4, padx=5,pady=5)
        askRefgenWindow.mainloop()

def run_external_program(command_to_run_and_args):
    if(platform.system()=="Windows"):
        for commindex, commvalue in enumerate(command_to_run_and_args):
            command_to_run_and_args[commindex] = commvalue.replace("/","\\")
    p = Popen(command_to_run_and_args)
    stdout, stderr = p.communicate()
    p.wait()

def button_generate_bam_index():
    global msgBAMIndexWindow
    msgBAMIndexWindow.destroy()
    samtools = "\"" +  path_to_samtools_cygwin + "samtools\""
    CommandsToRun = samtools + " index \""+mainWindow.inputbam_filename+"\"\n"
    run_batch_job("temp_indexbam",CommandsToRun)        
    resume_main_window_after_picking_bam()

def check_for_bam_index():
    global msgBAMIndexWindow
    if os.path.isfile(mainWindow.inputbam_filename + ".bai") or \
     os.path.isfile(mainWindow.inputbam_filename+ ".BAI") or \
     os.path.isfile(os.path.splitext(mainWindow.inputbam_filename)[0]+".bai") or \
     os.path.isfile(os.path.splitext(mainWindow.inputbam_filename)[0]+".BAI"):
        resume_main_window_after_picking_bam()
    else:
        msgBAMIndexWindow = Tk()
        msgBAMIndexWindow.title(wgse_lang.lstr['BamIndex'])
        msgBAMIndexWindow.geometry("")
        msgBAMIndexWindow.protocol("WM_DELETE_WINDOW",0)
        if(platform.system()=="Windows"):
            msgBAMIndexWindow.iconbitmap('favicon.ico')
        msgBAMIndexWindow.columnconfigure(0, weight=1)
        msgBAMIndexWindow.rowconfigure(0, weight=1)
        indexNeedsToBeCreatedLabel = Label(msgBAMIndexWindow, text=wgse_lang.lstr['InfoBamIndexWillBeGenerated'], font=("Times New Roman", 14), anchor="w", justify="left") 
        indexNeedsToBeCreatedLabel.grid(column=0, row=0, padx=5,pady=5)
        startIndexingButton = Button(msgBAMIndexWindow, text=wgse_lang.lstr['Ok'], font=("Times New Roman", 14),command=button_generate_bam_index)
        startIndexingButton.grid(column=0, row=1, padx=5,pady=5)
        msgBAMIndexWindow.update()        

def resume_main_window_after_picking_bam():
    if mainWindow.gender=="":
        button_samtools_stats(False)
    if mainWindow.totalReadDepthAverage < 10:
        messagebox.showwarning(wgse_lang.lstr['LowCoverageWindowTitle'], wgse_lang.lstr['LowCoverageWarning'])        
    mainWindow.update()
    mainWindow.deiconify()
    bamSelectedFileLabel.configure(text = os.path.basename(mainWindow.inputbam_filename) )
    referenceGenomeOfBamLabel.configure(text = mainWindow.BamAlignedToRefgenome)
    bamGenderLabel.configure(text = os.path.basename(mainWindow.gender) )
    bamAverageReadDepthLabel.configure(text = os.path.basename(str(mainWindow.totalReadDepthAverage) + "x") )
    bamAverageReadLengthLabel.configure(text = os.path.basename(str(mainWindow.avg_read_length)) )
    mainWindow.update()
    check_if_all_filenames_are_set_for_change_of_button_state()    
    
def set_refgenom_after_button_click(RefGenomNr):
    mainWindow.BamAlignedToRefgenome = RefGenomNr
    try:
        askRefgenWindow.destroy()
    except:
        pass
    check_for_bam_index()
       
def button_click__open_bam():
    mainWindow.gender = ""
    mainWindow.inputbam_filename = filedialog.askopenfilename(title = wgse_lang.lstr['SelectBamFile'],filetypes = ((wgse_lang.lstr['BamFiles'],"*.bam"),))
    if (check_path_for_spaces_and_special_chars(mainWindow.inputbam_filename)==False):
        mainWindow.inputbam_filename = ""
        mainWindow.gender = ""
        mainWindow.withdraw()
        messagebox.showerror(wgse_lang.lstr['InvalidPathWindowTitle'], wgse_lang.lstr['errBamFileSpecialChars'])
        mainWindow.deiconify()
    mainWindow.BamAlignedToRefgenome = "0"
    bamSelectedFileLabel.configure(text= os.path.basename(mainWindow.inputbam_filename))
    if mainWindow.inputbam_filename == "":
        mainWindow.gender=""
        bamGenderLabel.configure(text = "")
        referenceGenomeOfBamLabel.configure(text = "")
        bamAverageReadDepthLabel.configure(text = "")
        bamAverageReadLengthLabel.configure(text = "")
        bamSelectButton.configure(text = wgse_lang.lstr['SelectBamFile'])
    else:
        bamSelectButton.configure(text = wgse_lang.lstr['ChangeSelection'])
        determine_reference_genome_used_for_bam()
    check_if_all_filenames_are_set_for_change_of_button_state()

def show_please_wait_window():
    global pleaseWaitWindow
    pleaseWaitWindow = Tk()
    pleaseWaitWindow.title(wgse_lang.lstr['PleaseWait'])
    pleaseWaitWindow.geometry("")
    if(platform.system()=="Windows"):
        pleaseWaitWindow.iconbitmap('favicon.ico')
    pleaseWaitWindow.columnconfigure(0, weight=1)
    pleaseWaitWindow.rowconfigure(0, weight=1)
    pleaseWaitLabel = Label(pleaseWaitWindow, text=str(wgse_lang.lstr['PleaseWait']), font=("Times New Roman", 28, "bold"), anchor="center", justify="center")
    pleaseWaitLabel.grid(column=0, row=0, padx=56,pady=56)
    pleaseWaitWindow.update()

def button_samtools_stats(showStatsWindow=True):
    global statsWindow, pleaseWaitWindow
    mainWindow.withdraw()
    mainWindow.update()
    show_please_wait_window()
    
    samtools = path_to_samtools_cygwin + "samtools"
    if(platform.system()=="Windows"):
        cmd_head = confp_to_bash(path_to_samtools_cygwin + "head")
        cmd_awk = confp_to_bash(path_to_samtools_cygwin + "gawk")        
        samtools = confp_to_bash(samtools)
    elif(platform.system()=="Darwin"):
        cmd_head = "/usr/bin/head"
        cmd_awk = "/usr/bin/awk"
    else:
        cmd_head = "head"
        cmd_awk = "awk"
    commands_to_run = "\"" + samtools + "\" idxstats \"" + confp_to_bash(mainWindow.inputbam_filename) + "\" > \"" + confp_to_bash(path_to_temp) + "idxstats.csv\"\n"
    commands_to_run = commands_to_run + "\"" + samtools + "\" view \"" + confp_to_bash(mainWindow.inputbam_filename) + "\" | \"" + cmd_head + "\" -100000 | \"" + cmd_awk + "\" '{sum += length($10); count++} END {print sum/count}'" + " > \"" + confp_to_bash(path_to_temp) + "readlength.tmp\"\n"
    create_and_run_bash_script("get_samtools_stats.sh", commands_to_run, "samtools_stats", "", False)

    pleaseWaitWindow.destroy()
    if showStatsWindow==True:
        statsWindow = Tk()
        statsWindow.title(wgse_lang.lstr['BamFileStatistics'])
        statsWindow.geometry("")
        if(platform.system()=="Windows"):
            statsWindow.iconbitmap('favicon.ico')
        statsWindow.columnconfigure(0, weight=1)
        statsWindow.rowconfigure(0, weight=1)
        byChromFrame = LabelFrame(statsWindow)
        byChromFrame.grid(row=0, column=0, padx=5, pady=5)
        byChromFrame.columnconfigure(0, weight=1)
        byChromFrame.rowconfigure(0, weight=3)
        summaryFrame = LabelFrame(statsWindow, text=wgse_lang.lstr['Summary'], font=("Times New Roman", 20, "bold"))
        summaryFrame.grid(row=0, column=1, padx=10, pady=10)

    avg_read_length = int(float(open(path_to_temp + "readlength.tmp").read(1000).strip().replace(",","."))) 
    table_row=0
    table_column=0
    if showStatsWindow==True:
        table_header = ["Chr / DNA",wgse_lang.lstr['LenInModel'],"# Map Seg Read","# Unmap Seg Read",wgse_lang.lstr['MappedGbases'],wgse_lang.lstr['AverageReadDepthShort']]
        header_label = []
        for header_column in table_header:
            header_label.append(Label(byChromFrame, text=header_column, font=("Times New Roman", 16, 'bold'), anchor="w", justify="left") )
            header_label[table_column].grid(column=table_column, row=table_row, padx=15,pady=1)
            table_column=table_column+1
    table_row = table_row + 1
    table_column = 0

    valid_chroms = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14",
                    "15","16","17","18","19","20","21","22","X","Y","M","MT"]
    other_chroms_values = [wgse_lang.lstr['OtherChr'],0,0,0]
    total_values = [wgse_lang.lstr['Total'],0,0,0]
    stats_chroms = []
    with open(path_to_temp + "idxstats.csv","r") as stats_file:
        for stats_line in stats_file:
            line_columns = stats_line.split("\t")
            chromosome = line_columns[0].replace("chr","")
            if ( chromosome.strip() == "*"):
                additional_unmapped = line_columns[3].strip()
                stats_chroms.append(["*",0,0,line_columns[3].strip(),"",""])
                continue
            len_in_model_bp = int(line_columns[1])
            map_seg_read = int(line_columns[2])
            unmap_seg_read = int(line_columns[3].strip())
            if (chromosome in valid_chroms):
                stats_chroms.append([chromosome, len_in_model_bp,map_seg_read, unmap_seg_read])
            else:
               other_chroms_values[1] = other_chroms_values[1] + len_in_model_bp
               other_chroms_values[2] = other_chroms_values[2] + map_seg_read
               other_chroms_values[3] = other_chroms_values[3] + unmap_seg_read               
        stats_chroms.append(other_chroms_values)
        for i in range(len(stats_chroms)):
            for i2 in range(1,4):
                total_values[i2] = int(total_values[i2]) + int(stats_chroms[i][i2])
        stats_chroms.append(total_values)
        mapped_reads_percent = total_values[2]/(total_values[2]+total_values[3])
        for i in range(len(stats_chroms)):                
            if (stats_chroms[i][0] != "*"):
                len_in_model_bp = stats_chroms[i][1]            
                map_seg_read = stats_chroms[i][2]
                temp_mapped_gbases = float(map_seg_read * avg_read_length / 1000000000)
                stats_chroms[i].append(round(temp_mapped_gbases,2))
                stats_chroms[i].append(str(int(map_seg_read * avg_read_length / len_in_model_bp))+"x")

            if (stats_chroms[i][0] == "X"):
                mapped_gbases_x = stats_chroms[i][4]
            elif (stats_chroms[i][0] == "Y"):
                mapped_gbases_y = stats_chroms[i][4]

            for i2 in range(len(stats_chroms[i])):
                if (stats_chroms[i][0] == wgse_lang.lstr['Total']):
                    if showStatsWindow==True:
                        if (i2==0 or i2==4 or i2==5):
                            new_column = Label(byChromFrame, text=str(stats_chroms[i][i2]), font=("Times New Roman", 16, "bold"), anchor="w", justify="left") 
                        else:
                            new_column = Label(byChromFrame, text=str(stats_chroms[i][i2]), font=("Times New Roman", 14), anchor="w", justify="left")                     
                    totalReadDepthAverage = stats_chroms[i][5]
                    totalMappedGbases = stats_chroms[i][4]
                else:
                    if showStatsWindow==True:
                        new_column = Label(byChromFrame, text=str(stats_chroms[i][i2]), font=("Times New Roman", 14), anchor="w", justify="left") 
                if showStatsWindow==True:
                    new_column.grid(column=table_column, row=table_row, padx=10, pady=0)
                table_column = table_column + 1
            table_row = table_row + 1
            table_column = 0
        if (  (mapped_gbases_x/(mapped_gbases_y + 0.0001)) > 20 ):
            gender = wgse_lang.lstr['Female']
        else:
            gender = wgse_lang.lstr['Male']
    total_len_in_model = total_values[1]
    total_map_seg_read = total_values[2]
    total_unmap_seg_read = total_values[3]
    raw_gigabases = (total_map_seg_read+total_unmap_seg_read) * avg_read_length / 1000000000
    raw_avg_read_depth = (total_map_seg_read + total_unmap_seg_read) * avg_read_length / total_len_in_model 
    if showStatsWindow==True:
        summaryText = wgse_lang.lstr['AverageReadDepth'] + ":\n" + str(totalReadDepthAverage) + "\n\n" + wgse_lang.lstr['AverageReadLength'] + ":\n" + str(avg_read_length) + "\n\n------------\n\n" + wgse_lang.lstr['MappedReads'] + ":\n"
        summaryText = summaryText + str(round(mapped_reads_percent*100,2)) + "%\n\n" + wgse_lang.lstr['MappedGbases'] + ":\n" + str(totalMappedGbases) + "\n\n"
        summaryText = summaryText + wgse_lang.lstr['RawGbases'] + ":\n" + str(round(raw_gigabases,2)) + "\n\n------------\n\n" + wgse_lang.lstr['Gender'] + ":\n" + gender
        summLabel = Label(summaryFrame, text=summaryText, font=("Times New Roman", 18, "bold"), anchor="center", justify="center") 
        summLabel.grid(row=0, column=0, padx=10, pady=10)
        statsCloseButton = Button(summaryFrame, text=wgse_lang.lstr['CloseWindow'], font=("Times New Roman", 18, "bold"),command=button_stats_close, anchor="center")
        statsCloseButton.grid(column=0, row=2, padx=5, pady=10)
        statsWindow.mainloop()
    else:
        mainWindow.gender = gender
        mainWindow.totalReadDepthAverage = int(totalReadDepthAverage.replace("x",""))
        mainWindow.avg_read_length = avg_read_length

def button_stats_close():
    global statsWindow
    statsWindow.destroy()
    mainWindow.deiconify()

def button_click__open_output_path():
    mainWindow.outputfiles_path = filedialog.askdirectory()
    if (check_path_for_spaces_and_special_chars(mainWindow.outputfiles_path)==False):
        mainWindow.outputfiles_path = ""
        mainWindow.withdraw()
        messagebox.showerror(wgse_lang.lstr['InvalidPathWindowTitle'], wgse_lang.lstr['errOutputPathSpecialChars'])
        mainWindow.deiconify()
    outputSelectedPathLabel.configure(text= os.path.basename(mainWindow.outputfiles_path))
    if mainWindow.outputfiles_path == "":
        outputSelectPathButton.configure(text = wgse_lang.lstr['SelectOutputPath'])
    else:
        outputSelectPathButton.configure(text = wgse_lang.lstr['ChangeSelection'])
    check_if_all_filenames_are_set_for_change_of_button_state()

def button_continueAfterBatchJob():
    global batchjobWindow
    batchjobWindow.destroy()    
    try:
        resume_main_window_after_picking_bam()
    except:
        pass

def clean_temp_dir():
    global cleanup
    for f in cleanup:
        os.remove(f)
    cleanup.clear()
    filelist = [ f for f in os.listdir(path_to_temp) ]
    for f in filelist:
        os.remove(os.path.join(path_to_temp, f))
    #pass

def run_batch_job(filenameBatch,CommandsToRun, MessageForUser="", show_wait_window=True):
    global batchjobWindow
    if (show_wait_window == True):
        try:
            mainWindow.withdraw()
        except:
            pass
        batchjobWindow = Tk()
        batchjobWindow.title(wgse_lang.lstr['BatchJobInProgress'])
        batchjobWindow.geometry("")
        if(platform.system()=="Windows"):
            batchjobWindow.iconbitmap('favicon.ico')
        batchjobWindow.columnconfigure(0, weight=1)
        batchjobWindow.rowconfigure(0, weight=1)
        batchjobWindow.protocol("WM_DELETE_WINDOW",0)
        if MessageForUser == "":
            MessageForUser = wgse_lang.lstr['PleaseWaitUntilJobIsComplete']
        statusOfBatchJobLabel = Label(batchjobWindow, text=MessageForUser, font=("Times New Roman", 14), anchor="w", justify="left") 
        statusOfBatchJobLabel.grid(column=0, row=0, padx=5,pady=5)
        continueButton = Button(batchjobWindow, text=wgse_lang.lstr['Continue'], font=("Times New Roman", 14),command=button_continueAfterBatchJob, state = "disabled")
        continueButton.grid(column=0, row=1, padx=5,pady=5)
        batchjobWindow.update()    
    create_batch_file(path_to_temp + filenameBatch, CommandsToRun)
    filenameBatch = filenameBatch + os_batch_suffix
    run_external_program([path_to_temp + filenameBatch])
    if (show_wait_window == True):
        clean_temp_dir()
        continueButton.configure(state = "normal")
        statusOfBatchJobLabel.config(text=wgse_lang.lstr['JobIsDone'])
        batchjobWindow.mainloop()

def get_output_filename_without_suffix():
    output_filename_without_suffix = os.path.splitext(mainWindow.inputbam_filename)[0]
    output_filename_without_suffix = mainWindow.outputfiles_path+"/"+os.path.basename(output_filename_without_suffix)
    return(output_filename_without_suffix)    

def confp_to_bash(path):
    path = path.replace("\\","/")
    return path

def cancelAutosomalFormatsWindow():
    global selectAutosomalFormatsWindow
    selectAutosomalFormatsWindow.destroy()
    mainWindow.update()
    mainWindow.deiconify()    

def button_select_autosomal_formats():
    global combinedButton, g23andmev3Button, g23andmev4Button, g23andmev5Button, g23andmeAPIButton, MyHeritagev1Button, MyHeritagev2Button, generateSelectedFilesButton
    global checkbuttons_results, AncestryV1Button, AncestryV2Button, FTDNAv2Button, FTDNAv3Button, LDNAv1Button, LDNAv2Button, selectAutosomalFormatsWindow

    mainWindow.withdraw()
    selectAutosomalFormatsWindow = Tk()
    selectAutosomalFormatsWindow.protocol("WM_DELETE_WINDOW",cancelAutosomalFormatsWindow)
    selectAutosomalFormatsWindow.title(wgse_lang.lstr['TitleSelectAutosomalFormats'])
    selectAutosomalFormatsWindow.geometry("")
    if(platform.system()=="Windows"):
        selectAutosomalFormatsWindow.iconbitmap('favicon.ico')
    selectAutosomalFormatsWindow.columnconfigure(0, weight=1)
    selectAutosomalFormatsWindow.rowconfigure(0, weight=1)    
    questionAutosomalFormats = Label(selectAutosomalFormatsWindow, text=wgse_lang.lstr['QuestionWhichAutosomalFormats'], font=("Times New Roman", 16, 'bold'), anchor="nw", justify="left") 
    questionAutosomalFormats.grid(column=0, row=0, padx=5,pady=15)

    combinedFrame = LabelFrame(selectAutosomalFormatsWindow, text=wgse_lang.lstr['everythingCombined'], font=("Times New Roman", 14))
    combinedFrame.grid(row=1, padx=5, pady=3,  sticky=(N, S, E, W))
    combinedFrame.columnconfigure(0, weight=1)
    combinedFrame.rowconfigure(1, weight=1)
    g23andmeFrame = LabelFrame(selectAutosomalFormatsWindow, text="23andme", font=("Times New Roman", 14))
    g23andmeFrame.grid(row=2, padx=5, pady=3,  sticky=(N, S, E, W))
    g23andmeFrame.columnconfigure(0, weight=1)
    g23andmeFrame.rowconfigure(1, weight=1)
    ancestryFrame = LabelFrame(selectAutosomalFormatsWindow, text="Ancestry", font=("Times New Roman", 14))
    ancestryFrame.grid(row=3, padx=5, pady=3,  sticky=(N, S, E, W))
    ancestryFrame.columnconfigure(0, weight=1)
    ancestryFrame.rowconfigure(1, weight=1)
    ftdnaFrame = LabelFrame(selectAutosomalFormatsWindow, text="Family Tree DNA", font=("Times New Roman", 14))
    ftdnaFrame.grid(row=4, padx=5, pady=3,  sticky=(N, S, E, W))
    ftdnaFrame.columnconfigure(0, weight=1)
    ftdnaFrame.rowconfigure(1, weight=1)
    ldnaFrame = LabelFrame(selectAutosomalFormatsWindow, text="Living DNA", font=("Times New Roman", 14))
    ldnaFrame.grid(row=5, padx=5, pady=3,  sticky=(N, S, E, W))
    ldnaFrame.columnconfigure(0, weight=1)
    ldnaFrame.rowconfigure(1, weight=1)
    myheritageFrame = LabelFrame(selectAutosomalFormatsWindow, text="MyHeritage", font=("Times New Roman", 14))
    myheritageFrame.grid(row=6, padx=5, pady=3,  sticky=(N, S, E, W))
    myheritageFrame.columnconfigure(0, weight=1)
    myheritageFrame.rowconfigure(1, weight=1)
    buttonsFrame = Frame(selectAutosomalFormatsWindow)
    buttonsFrame.grid(row=7, padx=5, pady=3,  sticky=(N, S, E, W))
    buttonsFrame.columnconfigure(0, weight=1)
    buttonsFrame.rowconfigure(1, weight=1)    

    checkbuttons_results = []
    combinedButtonResult = BooleanVar()
    combinedButtonResult.set(False)
    checkbuttons_results.append(False)
    combinedButton = Checkbutton(combinedFrame, variable=combinedButtonResult, \
                font=("Times New Roman", 13), text=wgse_lang.lstr['CombinedFileAllSNPs'], \
                command=lambda:adna_checkbutton_click(0))
    combinedButton.grid(row=0, column=0, padx=1,pady=1,sticky=(N, S, E, W))   

    g23andmev3ButtonResult = BooleanVar()
    g23andmev3ButtonResult.set(False)
    checkbuttons_results.append(False)    
    g23andmev3Button = Checkbutton(g23andmeFrame, variable=g23andmev3ButtonResult, \
                font=("Times New Roman", 13), text='23andme v3 (11/2010 - 11/2013)', \
                command=lambda:adna_checkbutton_click(1))
    g23andmev3Button.grid(row=0, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    g23andmev4ButtonResult = BooleanVar()
    g23andmev4ButtonResult.set(False)
    checkbuttons_results.append(False)    
    g23andmev4Button = Checkbutton(g23andmeFrame, variable=g23andmev4ButtonResult, \
                font=("Times New Roman", 13), text='23andme v4 (11/2013 - 08/2017)', \
                command=lambda:adna_checkbutton_click(2))
    g23andmev4Button.grid(row=1, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    g23andmev5ButtonResult = BooleanVar()
    g23andmev5ButtonResult.set(False)
    checkbuttons_results.append(False)    
    g23andmev5Button = Checkbutton(g23andmeFrame, variable=g23andmev5ButtonResult, \
                font=("Times New Roman", 13), text='23andme v5 (' + wgse_lang.lstr['Since'] + ' 08/2017)', \
                command=lambda:adna_checkbutton_click(3))
    g23andmev5Button.grid(row=2, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    g23andmeAPIButtonResult = BooleanVar()
    g23andmeAPIButtonResult.set(False)
    checkbuttons_results.append(False)    
    g23andmeAPIButton = Checkbutton(g23andmeFrame, variable=g23andmeAPIButtonResult, \
                font=("Times New Roman", 13), text=wgse_lang.lstr['23andMeFutureSNPs'], \
                command=lambda:adna_checkbutton_click(4))
    g23andmeAPIButton.grid(row=3, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    AncestryV1ButtonResult = BooleanVar()
    AncestryV1ButtonResult.set(False)
    checkbuttons_results.append(False)    
    AncestryV1Button = Checkbutton(ancestryFrame, variable=AncestryV1ButtonResult, \
                font=("Times New Roman", 13), text='Ancestry v1 (01/2012 - 05/2016)', \
                command=lambda:adna_checkbutton_click(5))
    AncestryV1Button.grid(row=0, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    AncestryV2ButtonResult = BooleanVar()
    AncestryV2ButtonResult.set(False)
    checkbuttons_results.append(False)    
    AncestryV2Button = Checkbutton(ancestryFrame, variable=AncestryV2ButtonResult, \
                font=("Times New Roman", 13), text='Ancestry v2 (' + wgse_lang.lstr['Since'] + ' 05/2016)', \
                command=lambda:adna_checkbutton_click(6))
    AncestryV2Button.grid(row=1, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    FTDNAv2ButtonResult = BooleanVar()
    FTDNAv2ButtonResult.set(False)
    checkbuttons_results.append(False)    
    FTDNAv2Button = Checkbutton(ftdnaFrame, variable=FTDNAv2ButtonResult, \
                font=("Times New Roman", 13), text='FTDNA v2 (02/2011 - 04/2019)', \
                command=lambda:adna_checkbutton_click(7))
    FTDNAv2Button.grid(row=1, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    FTDNAv3ButtonResult = BooleanVar()
    FTDNAv3ButtonResult.set(False)
    checkbuttons_results.append(False)    
    FTDNAv3Button = Checkbutton(ftdnaFrame, variable=FTDNAv3ButtonResult, \
                font=("Times New Roman", 13), text='FTDNA v3 (' + wgse_lang.lstr['Since'] + ' 04/2019)', \
                command=lambda:adna_checkbutton_click(8))
    FTDNAv3Button.grid(row=2, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    LDNAv1ButtonResult = BooleanVar()
    LDNAv1ButtonResult.set(False)
    checkbuttons_results.append(False)    
    LDNAv1Button = Checkbutton(ldnaFrame, variable=LDNAv1ButtonResult, \
                font=("Times New Roman", 13), text='Living DNA v1 (09/2016 - 10/2018)', \
                command=lambda:adna_checkbutton_click(9))
    LDNAv1Button.grid(row=0, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    LDNAv2ButtonResult = BooleanVar()
    LDNAv2ButtonResult.set(False)
    checkbuttons_results.append(False)    
    LDNAv2Button = Checkbutton(ldnaFrame, variable=LDNAv2ButtonResult, \
                font=("Times New Roman", 13), text='Living DNA v2 (' + wgse_lang.lstr['Since'] + ' 10/2018)', \
                command=lambda:adna_checkbutton_click(10))
    LDNAv2Button.grid(row=1, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    MyHeritagev1ButtonResult = BooleanVar()
    MyHeritagev1ButtonResult.set(False)
    checkbuttons_results.append(False)    
    MyHeritagev1Button = Checkbutton(myheritageFrame, variable=MyHeritagev1ButtonResult, \
                font=("Times New Roman", 13), text='MyHeritage v1 (11/2016 - 03/2019)', \
                command=lambda:adna_checkbutton_click(11))
    MyHeritagev1Button.grid(row=0, column=0, padx=1,pady=1,sticky=(N, S, E, W))

    MyHeritagev2ButtonResult = BooleanVar()
    MyHeritagev2ButtonResult.set(False)
    checkbuttons_results.append(False)    
    MyHeritagev2Button = Checkbutton(myheritageFrame, variable=MyHeritagev2ButtonResult, \
                font=("Times New Roman", 13), text='MyHeritage v2 (' + wgse_lang.lstr['Since'] + ' 03/2019)', \
                command=lambda:adna_checkbutton_click(12))
    MyHeritagev2Button.grid(row=1, column=0, padx=1,pady=1,sticky=(N, S, E, W))
    selectAllFileFormatsButton = Button(buttonsFrame, text=wgse_lang.lstr['buttonSelectEverything'], font=("Times New Roman", 14),command=button_select_every_autosomal_test)
    selectAllFileFormatsButton.grid(column=0, row=0, padx=5,pady=5)
    deSelectAllFileFormatsButton = Button(buttonsFrame, text=wgse_lang.lstr['buttonDeselectEverything'], font=("Times New Roman", 14),command=button_deselect_every_autosomal_test)
    deSelectAllFileFormatsButton.grid(column=1, row=0, padx=5,pady=5)
    emptySpace = Label(buttonsFrame, width=20)
    emptySpace.grid(column=2, row=0, padx=5,pady=5)
    generateSelectedFilesButton = Button(buttonsFrame, text=wgse_lang.lstr['buttonGenerateSelectedFiles'], font=("Times New Roman", 14),command=button_generate_selected_autosomal_fileformats, state="disabled")
    generateSelectedFilesButton.grid(column=3, row=0, padx=5,pady=15)
    button_select_every_autosomal_test()
    selectAutosomalFormatsWindow.mainloop()

def button_select_every_autosomal_test():
    combinedButton.select()
    g23andmev3Button.select()
    g23andmev4Button.select()
    g23andmev5Button.select()
    g23andmeAPIButton.select()
    AncestryV1Button.select()
    AncestryV2Button.select()
    FTDNAv2Button.select()
    FTDNAv3Button.select()
    LDNAv1Button.select()
    LDNAv2Button.select()
    MyHeritagev1Button.select()
    MyHeritagev2Button.select()
    for i in range(0,len(checkbuttons_results)):
        checkbuttons_results[i] = True
    generateSelectedFilesButton.configure(state = "normal")
    adna_check_if_button_change_is_necessary()

def button_deselect_every_autosomal_test():
    combinedButton.deselect()
    g23andmev3Button.deselect()
    g23andmev4Button.deselect()
    g23andmev5Button.deselect()
    g23andmeAPIButton.deselect()
    AncestryV1Button.deselect()
    AncestryV2Button.deselect()
    FTDNAv2Button.deselect()
    FTDNAv3Button.deselect()
    LDNAv1Button.deselect()
    LDNAv2Button.deselect()
    MyHeritagev1Button.deselect()
    MyHeritagev2Button.deselect()    
    for i in range(0,len(checkbuttons_results)):
        checkbuttons_results[i] = False
    generateSelectedFilesButton.configure(state = "disabled")
    adna_check_if_button_change_is_necessary()

def adna_checkbutton_click(i):
    checkbuttons_results[i] = not checkbuttons_results[i]    
    adna_check_if_button_change_is_necessary()

def adna_check_if_button_change_is_necessary():
    number_of_selected_buttons = 0    
    for i in range(0,len(checkbuttons_results)):
        if (checkbuttons_results[i] == True):
           number_of_selected_buttons = number_of_selected_buttons + 1 
    if number_of_selected_buttons > 0 :
        generateSelectedFilesButton.configure(state = "normal")
    else:
        generateSelectedFilesButton.configure(state = "disabled")
    
def button_generate_selected_autosomal_fileformats():
    global selectAutosomalFormatsWindow, cleanup 
    if mainWindow.BamAlignedToRefgenome != "hs37d5":
        messagebox.showwarning(wgse_lang.lstr['NoHs37d5WarningTitle'], wgse_lang.lstr['NoHs37d5WarningText'].replace("{{refgenome}}",mainWindow.BamAlignedToRefgenome))
    possible_output_formats = [ 'All_SNPs_combined_RECOMMENDED','23andMe_V3','23andMe_V4','23andMe_V5','23andMe_SNPs_API','Ancestry_V1','Ancestry_V2','FTDNA_V2','FTDNA_V3','LDNA_V1','LDNA_V2','MyHeritage_V1','MyHeritage_V2']
    output_formats_to_use = []
    output_filename_without_suffix = get_output_filename_without_suffix()
    for i in range(0,len(checkbuttons_results)):
        if checkbuttons_results[i] == True:
            output_formats_to_use.append(possible_output_formats[i])
    selectAutosomalFormatsWindow.withdraw()
    output_filename_without_suffix = get_output_filename_without_suffix()
    outputfile_uncompressed = confp_to_bash(output_filename_without_suffix+"__CombinedKit_All_SNPs_RECOMMENDED.txt")
    hg38tohg19 = ""
    if mainWindow.BamAlignedToRefgenome == "hg38" or mainWindow.BamAlignedToRefgenome == "GRCh38":
        reftab = confp_to_bash(path_to_extract23 + "All_SNPs_combined_RECOMMENDED_hg38_ref.tab.gz")
        hg38tohg19 = "\"" + confp_to_bash(path_to_python) + python_binary + "\" \"" + confp_to_bash(path_to_wgsextract) + "hg38tohg19.py\"" + " \"" + confp_to_bash(output_filename_without_suffix+"__CombinedKit_All_SNPs_RECOMMENDED\"") + " hg38"
    elif mainWindow.BamAlignedToRefgenome == "hg19":
        reftab = confp_to_bash(path_to_extract23 + "All_SNPs_combined_RECOMMENDED_hg19_ref.tab.gz")
    else:
        reftab = confp_to_bash(path_to_extract23 + "All_SNPs_combined_RECOMMENDED_GRCh37_ref.tab.gz")
    refgenome = get_path_and_filename_of_reference_genome()
    temp_raw_vcf = confp_to_bash(path_to_temp + "temp_autosomes_raw.vcf.gz")
    temp_called_vcf = confp_to_bash(path_to_temp + "temp_autosomes_called.vcf.gz")
    temp_annotated_vcf = confp_to_bash(path_to_temp + "temp_autosomes_annotated.vcf.gz")
    temp_autosomes_result_tab = confp_to_bash(path_to_temp + "temp_autosomes_result.tab")
    temp_sorted_autosomes_res_tab = confp_to_bash(path_to_temp + "temp_autosomes_result_sorted.tab")
    samtools = confp_to_bash(path_to_samtools_mingw + "samtools")
    bcftools_mingw = confp_to_bash(path_to_samtools_mingw + "bcftools")
    bcftools_cygwin = confp_to_bash(path_to_samtools_cygwin + "bcftools")
    tabix = confp_to_bash(path_to_samtools_mingw + "tabix")
    if(platform.system()=="Darwin"):
        sed = confp_to_bash(path_to_samtools_cygwin + "gsed")
        sort = confp_to_bash(path_to_samtools_cygwin + "gsort")
        cat = confp_to_bash(path_to_samtools_cygwin + "gcat")  
    else:
        sed = confp_to_bash(path_to_samtools_cygwin + "sed")
        sort = confp_to_bash(path_to_samtools_cygwin + "sort")
        cat = confp_to_bash(path_to_samtools_cygwin + "cat")
    plink = confp_to_bash(path_to_main_folder + "programs" + os_slash + "plink" + os_slash + "windows" + os_slash + "plink")
    dos2unix = confp_to_bash(path_to_samtools_cygwin + "dos2unix")
    cmdzip = confp_to_bash(path_to_samtools_cygwin + "zip")
    f=open(path_to_extract23 + "extract23_script_template.txt", "r")
    contents = f.read()
    f.close()
    contents = contents.replace("{{input_bamfile_sorted}}",confp_to_bash(mainWindow.inputbam_filename))
    contents = contents.replace("{{refgenome}}",refgenome)
    contents = contents.replace("{{reftab}}",reftab)
    contents = contents.replace("{{outputfile_uncompressed}}",outputfile_uncompressed)
    contents = contents.replace("{{samtools}}",samtools)
    contents = contents.replace("{{bcftools_mingw}}",bcftools_mingw)
    contents = contents.replace("{{bcftools_cygwin}}",bcftools_cygwin)
    contents = contents.replace("{{tabix}}",tabix)
    contents = contents.replace("{{sed}}",sed)
    contents = contents.replace("{{sort}}",sort)
    contents = contents.replace("{{cat}}",cat)
    contents = contents.replace("{{dos2unix}}",dos2unix)    
    contents = contents.replace("{{zip}}",cmdzip)
    contents = contents.replace("{{temp_raw_vcf}}",temp_raw_vcf)
    contents = contents.replace("{{temp_called_vcf}}",temp_called_vcf)
    contents = contents.replace("{{temp_annotated_vcf}}",temp_annotated_vcf)
    contents = contents.replace("{{temp_autosomes_result_tab}}",temp_autosomes_result_tab)
    contents = contents.replace("{{temp_sorted_autosomes_res_tab}}",temp_sorted_autosomes_res_tab)    
    contents = contents.replace("{{hg38tohg19}}",hg38tohg19)    

    conv_commands = ""
    for single_output_format in output_formats_to_use:
        if single_output_format != "All_SNPs_combined_RECOMMENDED":
            conv_commands = conv_commands = conv_commands + "echo \"Generating file in format " + single_output_format + "\"\n" 
            conv_commands = conv_commands + "\"" + confp_to_bash(path_to_python) + python_binary + "\" \"" + confp_to_bash(path_to_wgsextract) \
                            + "aconv.py\" " + single_output_format + " \"" \
                            + outputfile_uncompressed + "\" \"" + confp_to_bash(output_filename_without_suffix) \
                            + "\"\n"
            conv_commands = conv_commands + "\"" + dos2unix + "\" \"" + output_filename_without_suffix + "_" + single_output_format + get_target_type_suffix(single_output_format) + "\"\n"
            conv_commands = conv_commands + "\"" + cmdzip + "\" -j \"" + output_filename_without_suffix + "_" + single_output_format + ".zip\"" + " \"" + output_filename_without_suffix + "_" + single_output_format + get_target_type_suffix(single_output_format) + "\"\n"
    contents = contents.replace("{{conversions}}",conv_commands)        
    cleanup.clear()
    if "All_SNPs_combined_RECOMMENDED" not in output_formats_to_use:
        cleanup.append(outputfile_uncompressed)
        cleanup.append(outputfile_uncompressed + ".zip")       
    selectAutosomalFormatsWindow.destroy()
    create_and_run_bash_script("extract23.sh", contents, "temp_autosomes")    

def create_and_run_bash_script(script_filename, script_contents, batch_name, batch_message="", show_wait_window=True):
    f= open(path_to_temp + script_filename,"w+")
    f.write(script_contents)
    f.close()
    CommandsToRun = "\"" + path_to_samtools_cygwin + "dos2unix\" \"" + path_to_temp + script_filename + "\"" + "\n"
    if platform.system()=="Darwin":
        CommandsToRun = CommandsToRun + "\"/bin/chmod\"" + " \"ugoa+x\" \"" + path_to_temp + script_filename + "\"" + "\n"
    elif platform.system()=="Linux":
        CommandsToRun = CommandsToRun + "\"chmod\"" + " \"ugoa+x\" \"" + path_to_temp + script_filename + "\"" + "\n"
    CommandsToRun = CommandsToRun + call_bash + "\"" + path_to_temp + script_filename + "\"" + "\n"
    run_batch_job(batch_name,CommandsToRun, batch_message, show_wait_window)    

def get_target_type_suffix(target_type_name_all):
    if target_type_name_all == "FTDNA_V1_Affy" or target_type_name_all == "FTDNA_V2" or target_type_name_all == "FTDNA_V3" \
     or target_type_name_all == "MyHeritage_V1" or target_type_name_all == "MyHeritage_V2":
        target_type_suffix = ".csv"
    elif target_type_name_all == "LDNA_V1" or target_type_name_all == "LDNA_V2" \
     or "23andMe" in target_type_name_all or "Ancestry" in target_type_name_all: 
        target_type_suffix = ".txt"
    return target_type_suffix

def get_path_and_filename_of_reference_genome():
    path_to_rg = confp_to_bash(path_to_main_folder + "reference_genomes" + os_slash)
    if mainWindow.BamAlignedToRefgenome == "hg19":
        filename_rg = "hg19.fa.gz"
    elif mainWindow.BamAlignedToRefgenome == "hs37d5":
        filename_rg = "hs37d5.fa.gz"
    elif mainWindow.BamAlignedToRefgenome == "GRCh37":
        filename_rg = "human_g1k_v37.fasta.gz"
    elif mainWindow.BamAlignedToRefgenome == "hg38":
        filename_rg = "hg38.fa.gz"
    elif mainWindow.BamAlignedToRefgenome == "GRCh38":
        filename_rg = "GCA_000001405.15_GRCh38_no_alt_analysis_set.fna.gz"    
    refgenome = "\"" + path_to_rg + os_slash + filename_rg + "\""
    return(refgenome)

def getNameChrM():
    if "hg" in mainWindow.BamAlignedToRefgenome or mainWindow.BamAlignedToRefgenome=="GRCh38":
        chrM = "chrM"
    else:
        chrM = "MT"
    return (chrM)

def getNameChrY():
    if "hg" in mainWindow.BamAlignedToRefgenome or mainWindow.BamAlignedToRefgenome=="GRCh38":
        chrY = "chrY"
    else:
        chrY = "Y"
    return (chrY)

def button_mitoFASTA(show_wait_window=True,temp_fasta=False):
    if mainWindow.BamAlignedToMito=="Yoruba":
        messagebox.showwarning(wgse_lang.lstr['YorubaWindowTitle'], wgse_lang.lstr['YorubaWarning'])    
        if temp_fasta == True:
            return
    if temp_fasta == False:
        output_filename_without_suffix = get_output_filename_without_suffix()
    else:
        output_filename_without_suffix = confp_to_bash(path_to_temp + "temp")
    refgenome = get_path_and_filename_of_reference_genome()
    samtools = "\"" +  path_to_samtools_mingw + "samtools\""
    bcftools = "\"" +  path_to_samtools_mingw + "bcftools\""
    tabix = "\"" +  path_to_samtools_mingw + "tabix\""
    tempChrMFile = "\"" + path_to_temp + "chrM.vcf.gz\""
    tempChrMFile_uncompressed = "\"" + path_to_temp + "chrM\""
    bgzip = "\"" +  path_to_samtools_cygwin + "bgzip\""
    if(platform.system()=="Darwin"):
        sed = confp_to_bash(path_to_samtools_cygwin + "gsed")
    else:
        sed = confp_to_bash(path_to_samtools_cygwin + "sed")
    chrM = getNameChrM()
    CommandsToRun = samtools + " mpileup -r " + chrM + " -u -C 50 -v -f " + refgenome + " \""+ mainWindow.inputbam_filename + "\"" + " | "
    CommandsToRun = CommandsToRun + bcftools + " call -O z -v -m -P 0 > " + tempChrMFile + "\n"
    CommandsToRun = CommandsToRun + tabix + " " + tempChrMFile + "\n"
    CommandsToRun = CommandsToRun + samtools + " faidx " + refgenome + " " + chrM + " | " + bcftools + " consensus " + tempChrMFile + " -o \""+output_filename_without_suffix+"_mtdna.fasta\"\n" 
    run_batch_job("temp_mitofasta",CommandsToRun, "", show_wait_window)

def button_yAndMt():
    chrM = getNameChrM()
    chrY = getNameChrY()
    samtools = "\"" +  path_to_samtools_cygwin + "samtools\""
    output_filename_without_suffix = get_output_filename_without_suffix()
    CommandsToRun = samtools + " view -b \""+mainWindow.inputbam_filename+"\" " + chrY + " " + chrM + " > \""+output_filename_without_suffix+"_only_chrY_and_chrM.bam\"" + "\n"
    run_batch_job("temp_yAndMt",CommandsToRun)

def button_yOnly():
    chrY = getNameChrY()
    samtools = "\"" +  path_to_samtools_cygwin + "samtools\""
    output_filename_without_suffix = get_output_filename_without_suffix()
    CommandsToRun = samtools + " view -b \""+mainWindow.inputbam_filename+"\" " + chrY + " > \""+output_filename_without_suffix+"_only_chrY.bam\"" + "\n"
    run_batch_job("temp_yOnly",CommandsToRun)

def button_exit():
    exit()
   
def button_set_language_english():
    set_language_after_button_click("English")

def button_set_language_deutsch():
    set_language_after_button_click("Deutsch")

def button_set_language_francaise():
    set_language_after_button_click("Française")

def set_language_after_button_click(languageForGUI):
    global path_to_language_strings, wgse_lang
    selectLanguageWindow.destroy()
    if languageForGUI == "English":
        wgse_lang = LanguageStrings(path_to_language_strings + "english.txt")
    elif languageForGUI == "Deutsch":
        wgse_lang = LanguageStrings(path_to_language_strings + "deutsch.txt")
    elif languageForGUI == "Française":
        wgse_lang = LanguageStrings(path_to_language_strings + "francaise.txt")

def check_path_for_spaces_and_special_chars(path_to_check):
    if re.match("^[a-zA-Z0-9_\\/\\-\\:\\~\\.\\\]*$", path_to_check):
        return True
    else:
        return False

def show_error_path_to_wgsextract_contains_invalid_chars():
    errPathHasInvalidCharsWindow = Tk()
    errPathHasInvalidCharsWindow.title(wgse_lang.lstr['InvalidPathWindowTitle'])
    errPathHasInvalidCharsWindow.geometry("")
    errPathHasInvalidCharsWindow.protocol("WM_DELETE_WINDOW",0)
    if(platform.system()=="Windows"):
        errPathHasInvalidCharsWindow.iconbitmap('favicon.ico')
    errPathHasInvalidCharsWindow.columnconfigure(0, weight=1)
    errPathHasInvalidCharsWindow.rowconfigure(0, weight=1)
    errMessInvPathLabel = Label(errPathHasInvalidCharsWindow, text=wgse_lang.lstr['InvalidPathErrorMessage'], font=("Times New Roman", 14), anchor="w", justify="left") 
    errMessInvPathLabel.grid(column=0, row=0, padx=5,pady=5)
    okExitButton = Button(errPathHasInvalidCharsWindow, text=wgse_lang.lstr['OkExit'], font=("Times New Roman", 14),command=button_exit)
    okExitButton.grid(column=0, row=1, padx=5,pady=5)
    errPathHasInvalidCharsWindow.mainloop()

def remove_temporary_yleaf_dir():
    shutil.rmtree(path_to_temp + "tempYleaf")
    clean_temp_dir()
    
def button_haplogroup_ydna():
    global pleaseWaitWindow
    if os.path.isdir(path_to_temp + "tempYleaf"):
        remove_temporary_yleaf_dir()
    mainWindow.withdraw()
    mainWindow.update()            
    show_please_wait_window()
    path_to_yleaf = path_to_main_folder + "programs" + os_slash + "yleaf" + os_slash
    if mainWindow.BamAlignedToRefgenome == "hg38" or mainWindow.BamAlignedToRefgenome == "GRCh38":
        position_file = "hg38.txt"
    else:
        position_file = "hg19.txt"
    cmd_to_run = confp_to_bash("\"" + path_to_python + python_binary + "\" \"" + path_to_yleaf + "Yleaf.py\" -r 3 -bam \"" + mainWindow.inputbam_filename.replace('\\','/') + "\" -pos \"" + path_to_yleaf.replace('\\','/') + "Position_files" + os_slash + position_file.replace('\\','/') + "\" -out \"" + path_to_temp.replace('\\','/')  + "tempYleaf\" -r 1 -q 20 -b 90 -py \"" + path_to_python.replace('\\','/') + python_binary + "\" -samt \"" + path_to_samtools_cygwin.replace('\\','/') + "samtools\"\n")
    create_and_run_bash_script("yleaf.sh", cmd_to_run, "start_yleaf", "", False)
    '''fp = open(confp_to_bash(path_to_temp + "tempYleaf" + os_slash + "tempYleaf.hg"))
    fpheader = fp.readline()
    fpdata = fp.readline()
    columns_yleaf_result = fpdata.split("\t")
    yhg = columns_yleaf_result[1]
    fp.close()'''
    fp = open(confp_to_bash(path_to_temp + "tempYleaf.hg" + "tmp_hg.txt"))    
    yhg = fp.readline().strip()
    fp.close()
    outfws = ntpath.basename(get_output_filename_without_suffix())
    if(platform.system()=="Windows"):
        more = path_to_samtools_cygwin.replace('\\','/') + "cat"
        awk = path_to_samtools_cygwin.replace('\\','/') + "gawk"
        grep = path_to_samtools_cygwin.replace('\\','/') + "grep"
    else:
        more = "more"
        grep = "grep"
        awk = "awk"
    commands_to_get_snps = "\"" + more + "\" \"" + path_to_temp + "tempYleaf/" + outfws + "/" + outfws + ".out\" | \"" + grep + "\" \"" + yhg + "\" | \"" + awk + "\" -F \"\\\"*\\t\\\"*\" '{print $3}' > \"" + path_to_temp + "snps_terminal.txt\"\n" 
    create_and_run_bash_script("get_terminal_snps.sh", commands_to_get_snps, "start_get_terminal_snps", "", False)
    terminal_snps = [line.rstrip('\n') for line in open(path_to_temp + "snps_terminal.txt")]
    remove_temporary_yleaf_dir()
    pleaseWaitWindow.destroy()
    yChromosomeHgResultWindow(yhg, terminal_snps)

def yChromosomeHgResultWindow(yhg, terminal_snps):
    yChromResWindow = Tk()
    yChromResWindow.title(wgse_lang.lstr['YChromHaplogroup'])
    yChromResWindow.geometry("")
    yChromResWindow.protocol("WM_DELETE_WINDOW", 0) 
    if(platform.system()=="Windows"):
        yChromResWindow.iconbitmap('favicon.ico')
    yhgresFrame = LabelFrame(yChromResWindow, text=wgse_lang.lstr['Haplogroup'], font=("Times New Roman", 18, "bold"))
    yhgresFrame.grid(row=0, column=0, padx=10, pady=10, sticky=(N, S, E, W))
    theYHgisLabel = Label(yhgresFrame, text=wgse_lang.lstr['TheYDNAHaplogroupForThisSampleIs'], font=("Times New Roman", 16) )
    theYHgisLabel.grid(column=0, row=0, padx=5,pady=5)
    haplogroupLabel = Label(yhgresFrame, text="\n" + yhg + "\n", font=("Times New Roman", 16,"bold") )
    haplogroupLabel.grid(column=0, row=1, padx=5,pady=0)
    snpsForHgFrame = LabelFrame(yChromResWindow, text="SNPs", font=("Times New Roman", 18,"bold"))
    snpsForHgFrame.grid(row=0, column=1, padx=10, pady=10, sticky=(N, S, E, W))
    snps_textline = ""
    full_snp_list = ""
    total_snp_count = 0
    for snp in terminal_snps:
        full_snp_list = full_snp_list + snp + "\n"
        if total_snp_count < 3:
            snps_textline = snps_textline + snp + "     "
        elif total_snp_count == 3:
            snps_textline.strip()
            snps_textline = snps_textline + " ..."
        total_snp_count = total_snp_count + 1
    snps_textline.strip()
    snpsForThisHgLabel = Label(snpsForHgFrame, text=wgse_lang.lstr['SNPsForThisHG'].replace('{{yhg}}',yhg).replace('{{snps}}',snps_textline), font=("Times New Roman", 16), justify=CENTER) 
    snpsForThisHgLabel.grid(column=0, row=0, padx=5, pady=5)        
    if total_snp_count >3:
        showMoreSnpsButton = Button(snpsForHgFrame, text=wgse_lang.lstr['showAllSnps'], font=("Times New Roman", 14),command=lambda:messagebox.showinfo(yhg + ": SNPs", full_snp_list))
        showMoreSnpsButton.grid(column=0, row=1, padx=5,pady=5)        
    findHgOtherTreesFrame = LabelFrame(yChromResWindow, text=wgse_lang.lstr['findHgOtherTrees'], font=("Times New Roman", 18, "bold"))
    findHgOtherTreesFrame.grid(row=2, columnspan=2, column=0, padx=10, pady=10, sticky=(N, S, E, W))
    findYfullDescLabel = Label(findHgOtherTreesFrame, text=wgse_lang.lstr['findHgYFullDescription'].replace('{{BspSNP}}',terminal_snps[0]), font=("Times New Roman", 14), anchor=W, justify=LEFT )
    findYfullDescLabel.grid(column=0, row=0, padx=5,pady=5)
    findYfullButton = Button(findHgOtherTreesFrame, text=wgse_lang.lstr['findOnYFullButtonText'], font=("Times New Roman", 14),command=lambda:webbrowser.open_new("https://yfull.com/search-snp-in-tree/"))
    findYfullButton.grid(column=0, row=1, padx=5,pady=5)
    findFTDNADescLabel = Label(findHgOtherTreesFrame, text=wgse_lang.lstr['findOnFTDNADescLabel'].replace('{{BspSNP}}',terminal_snps[0]).replace('{{url}}','https://www.familytreedna.com/public/y-dna-haplotree/' + yhg[0]), font=("Times New Roman", 14), anchor=W, justify=LEFT )
    findFTDNADescLabel.grid(column=0, columnspan=2, row=2, padx=5,pady=5)
    findFTDNAButton = Button(findHgOtherTreesFrame, text=wgse_lang.lstr['findOnFTDNAButtonText'], font=("Times New Roman", 14),command=lambda:webbrowser.open_new("https://www.familytreedna.com/public/y-dna-haplotree/" + yhg[0]))
    findFTDNAButton.grid(column=0, columnspan=2, row=3, padx=5,pady=5)
    warningOtherTreesAreDeeperLabel = Label(findHgOtherTreesFrame, text=wgse_lang.lstr['warningOtherTreesAreDeeper'], font=("Times New Roman", 14), anchor=W, justify=LEFT )
    warningOtherTreesAreDeeperLabel.grid(column=0, columnspan=2, row=4, padx=5,pady=5)
    remarkFrame = LabelFrame(yChromResWindow, text=wgse_lang.lstr['ImportantRemark'], font=("Times New Roman", 18, "bold"))
    remarkFrame.grid(row=3, column=0,columnspan=2, padx=10, pady=10, sticky=(N, S, E, W))
    remarkUploadToYfullLabel = Label(remarkFrame, text=wgse_lang.lstr['YfullRemark'].replace('{{yhg}}',yhg).replace('{{snps}}',snps_textline), font=("Times New Roman", 14),anchor=W, justify=LEFT)
    remarkUploadToYfullLabel.grid(column=0, row=0, padx=5,pady=5)    
    closeYChromResButton = Button(yChromResWindow, text=wgse_lang.lstr['CloseWindow'], font=("Times New Roman", 14),command=lambda:button_close_y_chrom_hg_res_menue(yChromResWindow))
    closeYChromResButton.grid(column=0, columnspan=2, row=4, padx=5,pady=5)
    yChromResWindow.mainloop()

def button_close_y_chrom_hg_res_menue(yChromResWindow):
    yChromResWindow.destroy()
    mainWindow.deiconify()    

def button_haplogroup_mtdna():
    global pleaseWaitWindow
    if mainWindow.BamAlignedToMito!="Yoruba":
        try:
            p = Popen(["java","-version"])
            stdout, stderr = p.communicate()
            p.wait()
        except:
            messagebox.showwarning(wgse_lang.lstr['NoJavaWindowTitle'], wgse_lang.lstr['NoJavaInstalledErrorMessage'])    
            return
        mainWindow.withdraw()
        mainWindow.update()            
        show_please_wait_window()
    button_mitoFASTA(False,True)
    if mainWindow.BamAlignedToMito=="Yoruba":
        return
    tempChrMFile = "\"" + path_to_temp + "chrM.vcf.gz\""
    haplogrep = "\"" + path_to_main_folder + "programs" + os_slash + "haplogrep" + os_slash + "haplogrep.jar" + "\""
    haplogroup_txt_filename = path_to_temp + "mtdna_haplogroup.txt"
    command_to_run = "java -jar " + haplogrep + " --in " + tempChrMFile + " --format vcf --out \"" + haplogroup_txt_filename + "\"\n"
    run_batch_job("run_haplogrep",command_to_run, "", False)
    mtdna_haplogroup = ""
    with open(haplogroup_txt_filename,"r") as source_content:
        for source_line in source_content:
            source_line = source_line.replace("\\","//")
            line_tabs = source_line.split("\t")
            if str(line_tabs[3]).replace('"','').strip() == "1":
                mtdna_haplogroup = line_tabs[2].replace('"','').strip()
    clean_temp_dir()
    pleaseWaitWindow.destroy()
    messagebox.showinfo(wgse_lang.lstr['MitochondrialDNA'], wgse_lang.lstr['TheMitochondrialHaplogroupForThisSampleIs'].replace("{{mthaplogroup}}",mtdna_haplogroup))
    mainWindow.deiconify()    

def button_export_unmapped_reads():
    global pleaseWaitWindow
    mainWindow.withdraw()
    mainWindow.update()
    show_please_wait_window()
    samtools = "\"" +  path_to_samtools_cygwin + "samtools\""
    gzip = "\"" +  path_to_samtools_cygwin + "bgzip\""
    output_filename_without_suffix = get_output_filename_without_suffix()
    CommandsToRun = samtools + " view -hbf 64 -@ 24 \"" + mainWindow.inputbam_filename + "\" '*' > \"" + path_to_temp + "Unmapped_R1.bam\"\n"
    CommandsToRun = CommandsToRun + samtools + " view -hbf 128 -@ 24 \"" + mainWindow.inputbam_filename + "\" '*' > \"" + path_to_temp + "Unmapped_R2.bam\"\n"
    CommandsToRun = CommandsToRun + samtools + " bam2fq \"" + path_to_temp + "Unmapped_R1.bam\" | " + gzip + " > \"" + output_filename_without_suffix + "__unmapped_R1.fastq.gz\"\n"
    CommandsToRun = CommandsToRun + samtools + " bam2fq \"" + path_to_temp + "Unmapped_R2.bam\" | " + gzip + " > \"" + output_filename_without_suffix + "__unmapped_R2.fastq.gz\"\n"
    CommandsToRun = CommandsToRun.replace("\\","/")
    create_and_run_bash_script("temp_exp_unmapped.sh",CommandsToRun, "run_temp_exp_unmapped", batch_message="", show_wait_window=False)
    clean_temp_dir()
    pleaseWaitWindow.destroy()
    temp_descript = wgse_lang.lstr['DescriptionUploadCosmosId']
    temp_descript = temp_descript.replace("{{fq1}}",output_filename_without_suffix + "__unmapped_R1.fastq.gz")
    temp_descript = temp_descript.replace("{{fq2}}",output_filename_without_suffix + "__unmapped_R2.fastq.gz")    
    messagebox.showinfo(wgse_lang.lstr['HowToContinue'], temp_descript)
    mainWindow.deiconify()

# MAIN PROGRAM
global cleanup, wgse_lang
cleanup = []
path_to_main_folder = (os.path.dirname(os.path.abspath(__file__)))

if(platform.system()=="Windows"):
    path_to_main_folder = path_to_main_folder.split("programs\\wgsextract")[0]
    path_to_extract23 = path_to_main_folder + "programs\\extract23\\"
    path_to_wgsextract = path_to_main_folder + "programs\\wgsextract\\"
    path_to_language_strings  = path_to_wgsextract + "language_strings\\"
    path_to_temp = path_to_main_folder +"temp\\"
    path_to_samtools_cygwin = path_to_main_folder + "programs\\samtools-cygwin\\"
    path_to_samtools_mingw = path_to_main_folder + "programs\\samtools-mingw\\"
    path_to_python = path_to_main_folder + "programs\\python\\"
    python_binary = "python"
    os_batch_suffix = ".bat"
    call_bash = "\"" + path_to_samtools_cygwin + "bash\" "
    os_slash = "\\"
elif(platform.system()=="Darwin"):
    path_to_main_folder = path_to_main_folder.split("programs/wgsextract")[0]
    path_to_extract23 = path_to_main_folder + "programs/extract23/"
    path_to_wgsextract = path_to_main_folder + "programs/wgsextract/"
    path_to_language_strings  = path_to_wgsextract + "language_strings/"
    path_to_temp = path_to_main_folder +"temp/"
    path_to_samtools_cygwin = "/opt/local/bin/"
    path_to_samtools_mingw = "/opt/local/bin/"
    path_to_python = "/usr/local/bin/"
    python_binary = "python3"
    os_batch_suffix = ".sh"
    call_bash = ""
    os_slash = "/"
else:
    path_to_main_folder = path_to_main_folder.split("programs/wgsextract")[0]
    path_to_extract23 = path_to_main_folder + "programs/extract23/"
    path_to_wgsextract = path_to_main_folder + "programs/wgsextract/"
    path_to_language_strings  = path_to_wgsextract + "language_strings/"
    path_to_temp = path_to_main_folder +"temp/"
    path_to_samtools_cygwin = ""
    path_to_samtools_mingw = ""
    path_to_python = ""
    python_binary = "python3"
    os_batch_suffix = ".sh"
    call_bash = ""
    os_slash = "/"
    	
# First let the user select the prefered language
selectLanguageWindow = Tk()
selectLanguageWindow.title("WGS Extract - please select language")
selectLanguageWindow.geometry("")
selectLanguageWindow.protocol("WM_DELETE_WINDOW", 0) 
if(platform.system()=="Windows"):
    selectLanguageWindow.iconbitmap('favicon.ico')
selectLanguageWindow.columnconfigure(0, weight=1)
selectLanguageWindow.rowconfigure(0, weight=1)

questionLanguageLabel = Label(selectLanguageWindow, text="Bitte wählen Sie Sprache:", font=("Times New Roman", 14) )
questionLanguageLabel.grid(column=0, row=0, padx=5,pady=5)
languageDeutschButton = Button(selectLanguageWindow, text="Deutsch", font=("Times New Roman", 14),command=button_set_language_deutsch)
languageDeutschButton.grid(column=1, row=0, padx=5,pady=5)
questionLanguageLabel = Label(selectLanguageWindow, text="Please select language:", font=("Times New Roman", 14) )
questionLanguageLabel.grid(column=0, row=1, padx=5,pady=5)
languageEnglishButton = Button(selectLanguageWindow, text="English", font=("Times New Roman", 14),command=button_set_language_english)
languageEnglishButton.grid(column=1, row=1, padx=5,pady=5)
questionLanguageLabel = Label(selectLanguageWindow, text="Veuillez choisir la langue:", font=("Times New Roman", 14) )
questionLanguageLabel.grid(column=0, row=2, padx=5,pady=5)
languageFrancaiseButton = Button(selectLanguageWindow, text="Française", font=("Times New Roman", 14),command=button_set_language_francaise)
languageFrancaiseButton.grid(column=1, row=2, padx=5,pady=5)
selectLanguageWindow.mainloop()

# Check of the path of the program contains spaces or special chars
if (check_path_for_spaces_and_special_chars(os.path.dirname(os.path.abspath(__file__)))==False):
    show_error_path_to_wgsextract_contains_invalid_chars()

# main window
mainWindow = Tk()
mainWindow.title("WGS Extract")
mainWindow.geometry("")
if(platform.system()=="Windows"):
    mainWindow.iconbitmap('favicon.ico')
mainWindow.columnconfigure(0, weight=1)
mainWindow.rowconfigure(0, weight=1)
mainWindow.outputfiles_path = ""
mainWindow.inputbam_filename = ""
mainWindow.inputfile_filetype = ""
mainWindow.BamAlignedToRefgenome = "0"
mainWindow.gender = ""
tabParent = ttk.Notebook(mainWindow)
tabSettings = ttk.Frame(tabParent)
tabExtract = ttk.Frame(tabParent)
tabOther = ttk.Frame(tabParent)
tabParent.add(tabSettings, text=wgse_lang.lstr['Settings'])
tabParent.add(tabExtract, text=wgse_lang.lstr['ExtractData'])
tabParent.add(tabOther, text=wgse_lang.lstr['Other'])
tabParent.grid(row=1, padx=10, pady=10)
tabParent.columnconfigure(0, weight=1)
tabParent.rowconfigure(0, weight=1)

print (wgse_lang.lstr['ExplainWhyTerminalWinIsOpen'])
clean_temp_dir()

# dna frame
dnaFrame = LabelFrame(mainWindow)
dnaFrame.grid(row=0, padx=10, pady=10)
dnaFrame.columnconfigure(0, weight=1)
dnaFrame.rowconfigure(0, weight=1)
canvasFrame = Frame(dnaFrame)
canvasFrame.grid(row=0,column=0)
dnaCanvas = Canvas(canvasFrame, width = 80, height = 162)      
dnaCanvas.grid(column=0, row=0)
dnaImage = ImageTk.PhotoImage(Image.open(path_to_wgsextract + "img/dna.png"))
dnaCanvas.create_image(1,1, anchor=NW, image=dnaImage) 
headlineFrame = Frame(dnaFrame)
headlineFrame.grid(row=0,column=1)
dnaLabel = Label(headlineFrame, text="WGS Extract", font=("Arial Black", 32))
dnaLabel.grid(column=1, row=0)

# Settings
fileSelectFrame = LabelFrame(tabSettings, text=wgse_lang.lstr['SelectSourceAndTarget'], font=("Times New Roman", 14))
fileSelectFrame.grid(row=1, padx=10, pady=10,  sticky=(N, S, E, W))
fileSelectFrame.columnconfigure(0, weight=1)
fileSelectFrame.rowconfigure(1, weight=1)

bamLabel = Label(fileSelectFrame, text=wgse_lang.lstr['QuestionExtractFromWhichBAMFile'], font=("Times New Roman", 14)) 
bamLabel.grid(column=0, row=0, padx=5,pady=5)
bamSelectButton = Button(fileSelectFrame, text=wgse_lang.lstr['SelectBamFile'], font=("Times New Roman", 14),command=button_click__open_bam)
bamSelectButton.grid(column=1, row=0, padx=5,pady=5)
bamLabel2 = Label(fileSelectFrame, text=wgse_lang.lstr['WhereToWriteResults'], font=("Times New Roman", 14)) 
bamLabel2.grid(column=0, row=1, padx=5,pady=5)
outputSelectPathButton = Button(fileSelectFrame, text=wgse_lang.lstr['SelectOutputPath'],font=("Times New Roman", 14), command=button_click__open_output_path)
outputSelectPathButton.grid(column=1, row=1, padx=5,pady=5)

fileInfoFrame = LabelFrame(tabSettings, text=wgse_lang.lstr['Overview'], font=("Times New Roman", 14))
fileInfoFrame.grid(row=2, padx=10, pady=10,  sticky=(N, S, E, W))
fileInfoFrame.columnconfigure(0, weight=1)
fileInfoFrame.rowconfigure(2, weight=1)

infoLabelTextWhichBam = Label(fileInfoFrame, text=wgse_lang.lstr['FilenameOfSourceBam'], font=("Times New Roman", 14))
infoLabelTextWhichBam.grid(column=0, row=0, padx=5,pady=5)
bamSelectedFileLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
bamSelectedFileLabel.grid(column=1, row=0, padx=5,pady=5)

infoLabelReferenceGenomeOfBam = Label(fileInfoFrame, text=wgse_lang.lstr['BAMAlignedToReferenceGenome'], font=("Times New Roman", 14))
infoLabelReferenceGenomeOfBam.grid(column=0, row=1, padx=5,pady=5)
referenceGenomeOfBamLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
referenceGenomeOfBamLabel.grid(column=1, row=1, padx=5,pady=5)

infoLabelAverageReadDepth = Label(fileInfoFrame, text=wgse_lang.lstr['AverageReadDepth'] + ":", font=("Times New Roman", 14))
infoLabelAverageReadDepth.grid(column=0, row=2, padx=5,pady=5)
bamAverageReadDepthLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
bamAverageReadDepthLabel.grid(column=1, row=2, padx=5,pady=5)

infoLabelAverageReadLength = Label(fileInfoFrame, text=wgse_lang.lstr['AverageReadLength'] + ":", font=("Times New Roman", 14))
infoLabelAverageReadLength.grid(column=0, row=3, padx=5,pady=5)
bamAverageReadLengthLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
bamAverageReadLengthLabel.grid(column=1, row=3, padx=5,pady=5)

infoLabelGender = Label(fileInfoFrame, text=wgse_lang.lstr['Gender'] + ":", font=("Times New Roman", 14))
infoLabelGender.grid(column=0, row=4, padx=5,pady=5)
bamGenderLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
bamGenderLabel.grid(column=1, row=4, padx=5,pady=5)

infoLabelTextWhichOutputPath = Label(fileInfoFrame, text=wgse_lang.lstr['OutputPathForExtractedFiles'], font=("Times New Roman", 14))
infoLabelTextWhichOutputPath.grid(column=0, row=5, padx=5,pady=5)
outputSelectedPathLabel = Label(fileInfoFrame, text="", font=("Times New Roman", 14, "bold")) 
outputSelectedPathLabel.grid(column=1, row=5, padx=5,pady=5)


# Extract
autosomesFrame = LabelFrame(tabExtract, text=wgse_lang.lstr['Autosomes'], font=("Times New Roman", 14))
autosomesFrame.grid(row=2, padx=10, pady=10,  sticky=(N, S, E, W))
autosomesFrame.columnconfigure(0, weight=1)
autosomesFrame.rowconfigure(1, weight=1)
mitoFrame = LabelFrame(tabExtract, text=wgse_lang.lstr['MitochondrialDNA'], font=("Times New Roman", 14))
mitoFrame.grid(row=3, padx=10, pady=10,sticky=(N, S, E, W))
mitoFrame.columnconfigure(0, weight=1)
mitoFrame.rowconfigure(0, weight=1)
yFrame = LabelFrame(tabExtract, text=wgse_lang.lstr['YDNA'], font=("Times New Roman", 14))
yFrame.grid(row=4, padx=10, pady=10,sticky=(N, S, E, W))
yFrame.columnconfigure(1, weight=1)
yFrame.rowconfigure(1, weight=1)

autosomesLabel = Label(autosomesFrame, text=wgse_lang.lstr['AutosomesDescriptionNeededFor'], font=("Times New Roman", 14)) 
autosomesLabel.grid(column=0, row=0, padx=5,pady=5)
goToSelectAutosomalFormatsButton = Button(autosomesFrame, text=wgse_lang.lstr['GoToSelectAutosomalFormats'], font=("Times New Roman", 14),command=button_select_autosomal_formats,state = "disabled")
goToSelectAutosomalFormatsButton.grid(column=0, row=1, padx=5,pady=5)

mtLabel = Label(mitoFrame, text=wgse_lang.lstr['MitochondrialDescriptionNeededFor'], font=("Times New Roman", 14)) 
mtLabel.grid(column=0, row=0, padx=5,pady=5)
mitoFASTAButton = Button(mitoFrame, text=wgse_lang.lstr['GenerateFastaMtdna'], font=("Times New Roman", 14),command=button_mitoFASTA,state = "disabled")
mitoFASTAButton.grid(column=0, row=1, padx=5,pady=5)

yANDmtLabel = Label(yFrame, text=wgse_lang.lstr['RequiredForUploadingToYfull'], font=("Times New Roman", 14)) 
yANDmtLabel.grid(column=0, row=0, padx=5,pady=5)
yANDmtButton = Button(yFrame, text=wgse_lang.lstr['GenerateBAMwithYandMtdna'], font=("Times New Roman", 14),command=button_yAndMt,state = "disabled")
yANDmtButton.grid(column=1, row=0, padx=5,pady=5)
yOnlyLabel = Label(yFrame, text=wgse_lang.lstr['RequiredForYDNAWarehouse'], font=("Times New Roman", 14)) 
yOnlyLabel.grid(column=0, row=1, padx=5,pady=5)
yOnlyButton = Button(yFrame, text=wgse_lang.lstr['GenerateBAMOnlyWithY'], font=("Times New Roman", 14),command=button_yOnly,state = "disabled")
yOnlyButton.grid(column=1, row=1, padx=5,pady=5)

# Other
qualityCheckFrame = LabelFrame(tabOther, text=wgse_lang.lstr['CheckBamQuality'], font=("Times New Roman", 14))
qualityCheckFrame.grid(row=1, padx=10, pady=10,  sticky=(N, S, E, W))
qualityCheckFrame.columnconfigure(0, weight=1)
qualityCheckFrame.rowconfigure(1, weight=1)

bamCheckWithSamtoolsLabel = Label(qualityCheckFrame, text=wgse_lang.lstr['BamCheckSamtoolsDescription'], font=("Times New Roman", 14)) 
bamCheckWithSamtoolsLabel.grid(column=0, row=0, padx=5,pady=5)
bamCheckWithSamtoolsButton = Button(qualityCheckFrame, text=wgse_lang.lstr['BamCheckSamtoolsButton'], font=("Times New Roman", 14),command=button_samtools_stats,state = "disabled")
bamCheckWithSamtoolsButton.grid(column=1, row=0, padx=5,pady=5)

haplogroupFrame = LabelFrame(tabOther, text=wgse_lang.lstr['Haplogroups'], font=("Times New Roman", 14))
haplogroupFrame.grid(row=2, padx=10, pady=10,  sticky=(N, S, E, W))
haplogroupFrame.columnconfigure(0, weight=1)
haplogroupFrame.rowconfigure(1, weight=1)

determinehaplogroupLabel = Label(haplogroupFrame, text=wgse_lang.lstr['DetermineHaplogroups'], font=("Times New Roman", 14)) 
determinehaplogroupLabel.grid(column=0, row=0, padx=5,pady=5)
haplogroupYButton = Button(haplogroupFrame, text=wgse_lang.lstr['YDNA'], font=("Times New Roman", 14),command=button_haplogroup_ydna, state = "disabled")
haplogroupYButton.grid(column=1, row=0, padx=5,pady=5)
haplogroupMtButton = Button(haplogroupFrame, text=wgse_lang.lstr['MitochondrialDNA'], font=("Times New Roman", 14),command=button_haplogroup_mtdna, state = "disabled")
haplogroupMtButton.grid(column=2, row=0, padx=5,pady=5)

oralMicrobiomeFrame = LabelFrame(tabOther, text=wgse_lang.lstr['OralMicrobiome'], font=("Times New Roman", 14))
oralMicrobiomeFrame.grid(row=3, padx=10, pady=10,  sticky=(N, S, E, W))
oralMicrobiomeFrame.columnconfigure(0, weight=1)
oralMicrobiomeFrame.rowconfigure(1, weight=1)

forUploadsCosmosIdLabel = Label(oralMicrobiomeFrame, text=wgse_lang.lstr['ForUploadsCosmosId'], font=("Times New Roman", 14)) 
forUploadsCosmosIdLabel.grid(column=0, row=0, padx=5,pady=5)
exportUnmappedReadsButton = Button(oralMicrobiomeFrame, text=wgse_lang.lstr['ExportUnmappedReads'], font=("Times New Roman", 14),command=button_export_unmapped_reads, state = "disabled")
exportUnmappedReadsButton.grid(column=1, row=0, padx=5,pady=5)

# Button to exit program
exitButton = Button(mainWindow, text=wgse_lang.lstr['ExitProgram'], font=("Times New Roman", 14),command=button_exit)
exitButton.grid(row=2, pady=10)
exitButton.columnconfigure(0, weight=1)
exitButton.rowconfigure(0, weight=1)

mainWindow.mainloop()
