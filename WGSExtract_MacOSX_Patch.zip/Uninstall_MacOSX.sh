#!/bin/sh
# WGS Extract MacOSX Uninstall Script
# Copyright (C) 2020 Randolph Harr
#
# License: GNU General Public License v3 or later
# A copy of GNU GPL v3 should have been included in this software package in LICENSE.txt.
#
export TERM=xterm       # Needed when run from Applescript
clear

# Really hate using all these "sudo rm -rf" in here.  Prone to catastrophic error

echo "WGS Extract assumes it installed Python 3.8, MacPorts and Java along"
echo "with associated modules like htslib, pyliftover and such.  We will now"
echo "uninstall all except Java; as Java was likely already installed."
echo "Note that MacOSX 10.15 Catalina comes with Python 3.7 preinstalled in a"
echo "system area as a stub. We will not touch that."
echo "Should run this script with 'sudo -H' at the start. "
echo "If not, will require a password now"
echo

echo "Uninstalling Python 3.8 ... (ignoring native Python3 in Catalina)"
if [ -f /Library/Frameworks/Python.framework/Versions/3.8 ]; then
    echo "Removing any Python 3.8 libraries and modules ..."
    sudo -H rm -rf /Library/Frameworks/Python.framework/Versions/3.8
fi

echo
if [ -f /usr/local/bin/python3 ]; then
    echo " ... and now the Python 3.8 application is being removed"
    sudo -H rm -rf "/Applications/Python 3.8"
    sudo -H rm -f /usr/local/bin/python3
else
    echo " ... Python 3.8 already uninstalled"
fi
echo

# See https://guide.macports.org/chungked/installing_macports_uninstalling.html
echo "Uninstalling MacPorts ..."
if [ -f /opt/local/bin/port ]; then
    # Find it hard to believe that only MacPorts installs in /opt/local
    #  and we just wipe it out entirely
    echo "MacPorts is deleting packages previously installed ..."
    sudo -H /opt/local/bin/port -fp uninstall installed

    echo " ... and now deleting the main MacPorts installation."
    sudo dscl . -delete /Users/macports
    sudo dscl . -delete /Groups/macports
    sudo -H rm -rf /opt/local \
    	/Applications/DarwinPorts \
    	/Applications/MacPorts \
	/Library/LaunchDaemons/org.macports.* \
	/Library/Receipts/DarwinPorts*.pkg \
	/Library/Receipts/MacPorts*.pkg \
	/Library/StartupItems/DarwinPortsStartup \
	/Library/Tcl/darwinports1.0 \
	/Library/Tcl/macports1.0 \
	~/.macports
else
    echo "Macports is not found: "
fi
echo

echo "Leaving Java alone ... "

# Todo need to wipe needed JAR files if not in main release (GATK, Haplogrep?)

echo "Finished installing or upgrading programs needed by WGSExtract. "
echo "*** Please drag the WGSExtract program folder to the trash yourself. "
# Already have path in applescript so leave the command for there
